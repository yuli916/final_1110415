import os
import xml.etree.ElementTree as ET

# 設定資料夾路徑
annotations_dir = "positives/annotations"
images_dir = "positives/images"
output_path = "info/info.lst"

# 如果 info 資料夾不存在，先建立
os.makedirs("info", exist_ok=True)

# 開啟輸出檔案
with open(output_path, "w") as out:
    for filename in os.listdir(annotations_dir):
        if not filename.endswith(".xml"):
            continue

        xml_path = os.path.join(annotations_dir, filename)
        tree = ET.parse(xml_path)
        root = tree.getroot()

        img_name = root.find("filename").text
        img_path = os.path.join(images_dir, img_name)

        for obj in root.findall("object"):
            bndbox = obj.find("bndbox")
            xmin = int(float(bndbox.find("xmin").text))
            ymin = int(float(bndbox.find("ymin").text))
            xmax = int(float(bndbox.find("xmax").text))
            ymax = int(float(bndbox.find("ymax").text))
            w = xmax - xmin
            h = ymax - ymin

            out.write(f"{img_path} 1 {xmin} {ymin} {w} {h}\n")

print("✅ info.lst 已成功產生！")
